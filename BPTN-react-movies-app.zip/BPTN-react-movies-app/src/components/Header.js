import React from 'react'
import { Link } from 'react-router-dom'
import {Router} from "react-router";
// import 'antd/dist/antd.css'
// import { Menu, Icon } from 'antd'

const Header = (props) => {
    return (
        <Router >
            <div className='container'>
                <ul>
                    <li><Link to={"/"}>Home</Link></li>
                    <li><Link to={"/liked"}>Liked</Link></li>
                </ul>
            </div>

        </Router>
    )
}
export default Header;