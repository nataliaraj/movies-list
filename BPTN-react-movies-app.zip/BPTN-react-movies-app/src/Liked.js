import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';
import MovieList from './components/MovieList';
import MovieListHeading from './components/MovieListHeading';
import RemoveFavourites from './components/RemoveFavourites';

const Liked = (props) => {
	

	return (
		<div className='container-fluid movie-app'>
			
			<div className='row d-flex align-items-center mt-4 mb-4'>
				<MovieListHeading heading='Favourites' />
			</div>
			<div className='row'>
				<MovieList
					movies={props.favourites}
					 handleFavouritesClick={props.removeFavouriteMovie}
					 favouriteComponent={RemoveFavourites}
				/>
			</div>
		</div>
	);
};

export default Liked;
